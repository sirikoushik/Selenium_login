package demo;

import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginCreation {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\nkoushik\\Desktop\\selenium work space\\driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.navigate().to("http://demowebshop.tricentis.com/");
		/*
		 * driver.findElement(By.linkText("Register")).click();
		 * driver.findElement(By.id("gender-male")).click();
		 * driver.findElement(By.name("FirstName")).sendKeys("hii");
		 * driver.findElement(By.name("LastName")).sendKeys("hello");
		 * driver.findElement(By.name("Email")).sendKeys("hii@gmail.com");
		 * driver.findElement(By.name("Password")).sendKeys("Hii@123");
		 * driver.findElement(By.name("ConfirmPassword")).sendKeys("Hii@123");
		 * driver.findElement(By.id("register-button")).click();
		 * driver.findElement(By.linkText("Log in")).click();
		 * 
		 * driver.findElement(By.name("Email")).sendKeys("hii@gmail.com");
		 * driver.findElement(By.name("Password")).sendKeys("Hii@123");
		 * driver.findElement(By.xpath("//input[@value='Log in']")).click();
		 */

		driver.manage().window().maximize();
		Thread.sleep(5000);
		// minimize
		driver.manage().window().setPosition(new Point(-2000, 0));

	}
}
