package demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Invoke_Browser {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver","C:\\Users\\nkoushik\\Desktop\\selenium work space\\driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
	//	driver.get("https://www.capgemini.com");
//		 driver.navigate().to("https://www.google.com");
//		 String title=driver.getTitle();
//		// driver.findElement(By.id("gb_70")).click();
//		 driver.findElement(By.name("q")).sendKeys("capgemini");
//		 Thread.sleep(3000);
//		 driver.findElement(By.name("btnK")).click();
		 
		 driver.navigate().to("http://demowebshop.tricentis.com/");
		/* driver.findElement(By.linkText("Register")).click();
		 driver.findElement(By.id("gender-male")).click();
		 driver.findElement(By.name("FirstName")).sendKeys("hii");
		 driver.findElement(By.name("LastName")).sendKeys("hello");
		 driver.findElement(By.name("Email")).sendKeys("hii@gmail.com");
		 driver.findElement(By.name("Password")).sendKeys("Hii@123");
		 driver.findElement(By.name("ConfirmPassword")).sendKeys("Hii@123");
		 driver.findElement(By.id("register-button")).click();*/
		 driver.findElement(By.linkText("Log in")).click();
		
		 driver.findElement(By.name("Email")).sendKeys("hii@gmail.com");
		 driver.findElement(By.name("Password")).sendKeys("Hii@123");
		 driver.findElement(By.xpath("//input[@value='Log in']")).click();
//		 System.out.println(title);
//		 driver.findElement(By.linkText("Images")).click();
//		 String title2=driver.getCurrentUrl();
//		 System.out.println(title2);
//		 Thread.sleep(3000);
//		 driver.navigate().back();
//		 String title3=driver.getTitle();
//		 System.out.println(title3);
		 
	}
	
	
}
